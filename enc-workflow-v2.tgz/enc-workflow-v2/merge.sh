#!/bin/sh
# merge.sh — add new files to the published site
#
# Run from: /var/www/utils/<domain>/
# Processes files dropped in the add/ subdirectory:
#
#   add/foo.html    → encrypt → files/html/foo.html + update index.html
#   add/paper.pdf   → encrypt → files/misc/paper.pdf.enc + .sig (no index update)
#   add/data.csv    → encrypt → files/misc/data.csv.enc + .sig (no index update)
#
# HTML files are added to the index. Non-HTML files go to files/misc/.
# After processing, source files are moved from add/ to their proper
# source directory (html/ or misc/) so they persist for future republish.
#
# Usage: sh merge.sh

set -e

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
DOMAIN="$(basename "$SCRIPT_DIR")"
UTILS="$SCRIPT_DIR"
HTDOCS="/var/www/htdocs/$DOMAIN"
ADD_DIR="$UTILS/add"

if [ ! -d "$ADD_DIR" ]; then
    echo "No add/ directory found at $ADD_DIR"
    exit 1
fi

# Count files to process
count=$(find "$ADD_DIR" -maxdepth 1 -type f | wc -l)
if [ "$count" -eq 0 ]; then
    echo "No files in $ADD_DIR — nothing to merge."
    exit 0
fi

echo "=== $DOMAIN — merge ($count files) ==="
echo

PP="$UTILS/passphrase.txt"
if [ ! -f "$PP" ] || [ ! -s "$PP" ]; then
    echo "Error: passphrase not found: $PP" >&2
    exit 1
fi

html_added=0
other_added=0

for f in "$ADD_DIR"/*; do
    [ -f "$f" ] || continue
    name="$(basename "$f")"
    ext="${name##*.}"

    case "$ext" in
        html|htm)
            # HTML file → encrypt to files/html/ with embedded JS
            echo "  [html] $name"
            mkdir -p "$HTDOCS/files/html"
            python3 "$UTILS/encrypt-html.py" "$f" "$HTDOCS/files/html/" --sign
            # Move source to html/ for future republish
            mkdir -p "$UTILS/html"
            mv "$f" "$UTILS/html/$name"
            html_added=$((html_added + 1))
            ;;
        *)
            # Non-HTML → encrypt to files/misc/ as .enc + .sig
            echo "  [enc]  $name"
            mkdir -p "$HTDOCS/files/misc" "$UTILS/misc"
            python3 "$UTILS/encrypt-html.py" "$f" "$HTDOCS/files/misc/" --sign
            # Move source to misc/ for future republish
            mv "$f" "$UTILS/misc/$name"
            other_added=$((other_added + 1))
            ;;
    esac
done

echo
echo "  HTML added:  $html_added"
echo "  Other added: $other_added"

# Rebuild index if any HTML files were added
if [ "$html_added" -gt 0 ]; then
    echo
    echo "--- Rebuilding index ---"
    python3 "$UTILS/gen-site-index.py" "$DOMAIN"
fi

echo
echo "=== Merge complete ==="
