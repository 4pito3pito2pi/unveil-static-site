#!/usr/bin/env python3
"""
gen-site-index.py — Generate encrypted index.html for a domain.

Scans /var/www/htdocs/<domain>/files/html/ for encrypted HTML files,
builds an index page with links to each, encrypts and signs it, and
writes it to /var/www/htdocs/<domain>/index.html.

The index page is itself encrypted with the same passphrase and has
an embedded JS decryptor.

Usage:
  gen-site-index.py <domain>       e.g. gen-site-index.py dpcpbp.org
"""

import sys
import re
import json
from pathlib import Path
from datetime import datetime

# Reuse crypto from encrypt-html.py
from importlib.machinery import SourceFileLoader
_enc = SourceFileLoader("enc", str(Path(__file__).parent / "encrypt-html.py")).load_module()

UTILS_BASE  = Path("/var/www/utils")
HTDOCS_BASE = Path("/var/www/htdocs")


def extract_encrypted_title(html: str, fallback: str) -> str:
    """Extract original title from an already-encrypted HTML file."""
    m = re.search(r'<title>(.*?)\s*\[encrypted\]</title>', html, re.I)
    if m:
        return m.group(1).strip()
    m = re.search(r'<title>(.*?)</title>', html, re.I)
    return m.group(1).strip() if m else fallback


def build_index_html(domain: str, items: list[tuple[str, str, str]]) -> str:
    """Build plaintext index page. items: [(filename, title, href), ...]"""
    generated = datetime.utcnow().strftime("%Y-%m-%d %H:%M UTC")
    links = "\n".join(
        f'<li><a href="{href}">{title}</a></li>'
        for _, title, href in items
    )
    return f"""<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>{domain}</title>
  <style>
    body {{ font-family: sans-serif; background: #111; color: #ccc;
           max-width: 800px; margin: 2rem auto; padding: 0 1rem; }}
    .header {{ display: flex; justify-content: space-between; align-items: baseline;
               border-bottom: 1px solid #222; padding-bottom: 0.8rem; margin-bottom: 1.2rem; }}
    h1 {{ font-size: 1rem; color: #888; font-weight: normal; margin: 0; }}
    a.files-link {{ font-size: 0.85rem; color: #7aa2c8; text-decoration: none; }}
    a.files-link:hover {{ text-decoration: underline; }}
    ul {{ list-style: none; padding: 0; margin: 0; column-count: 2; column-gap: 2rem; }}
    li {{ padding: 0.15rem 0; font-size: 0.85rem; break-inside: avoid; }}
    li a {{ color: #aaa; text-decoration: none; }}
    li a:hover {{ color: #ddd; }}
    .footer {{ margin-top: 2rem; font-size: 0.75rem; color: #333;
               border-top: 1px solid #1a1a1a; padding-top: 0.8rem; }}
  </style>
</head>
<body>
<div class="header">
  <h1>{domain} &mdash; {len(items)} documents</h1>
  <a class="files-link" href="files/">Files &amp; Downloads &rarr;</a>
</div>
<ul>
{links}
</ul>
<p class="footer">Generated {generated} &middot; All documents encrypted &middot; <a href="files/pubkey.asc" style="color:#333">pubkey.asc</a></p>
</body>
</html>
"""


def main():
    if len(sys.argv) < 2:
        print(__doc__)
        sys.exit(1)

    domain = sys.argv[1]
    utils_dir  = UTILS_BASE / domain
    htdocs_dir = HTDOCS_BASE / domain
    files_html = htdocs_dir / "files" / "html"

    pp_file = utils_dir / "passphrase.txt"
    if not pp_file.exists() or not pp_file.stat().st_size:
        print(f"Error: passphrase not found: {pp_file}", file=sys.stderr)
        sys.exit(1)
    passphrase = pp_file.read_text().strip()

    if not files_html.is_dir():
        print(f"No files/html/ directory: {files_html}", file=sys.stderr)
        sys.exit(1)

    # Collect encrypted HTML files and extract their titles
    items = []
    for f in sorted(files_html.iterdir()):
        if f.is_file() and f.suffix.lower() in (".html", ".htm"):
            title = extract_encrypted_title(f.read_text(errors="replace"), f.stem)
            items.append((f.name, title, f"files/html/{f.name}"))

    print(f"  Building index: {len(items)} documents")

    # Build plaintext index, then encrypt it
    plaintext = build_index_html(domain, items)
    enc = _enc.encrypt(plaintext.encode("utf-8"), passphrase)
    enc_json = json.dumps(enc)
    sig_armor = _enc.gpg_sign_data(enc_json.encode())
    wrapped = _enc.wrap_html_encrypted(enc, domain, "index.html", sig_armor)

    dest = htdocs_dir / "index.html"
    dest.write_text(wrapped)
    print(f"  index.html → {dest} ({len(items)} documents)")


if __name__ == "__main__":
    main()
