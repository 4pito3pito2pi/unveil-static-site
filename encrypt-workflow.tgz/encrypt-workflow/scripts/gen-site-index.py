#!/usr/bin/env python3
"""
gen-site-index.py — generate the root index.html for a domain

Scans /var/www/htdocs/<domain>/html/ for encrypted HTML files, extracts
their titles, and writes /var/www/htdocs/<domain>/index.html — a sorted
alphabetical listing with a "Files →" link at the top.

Usage:
  gen-site-index.py <domain>       e.g. gen-site-index.py dpcpbp.org
  gen-site-index.py <htdocs_dir>   e.g. gen-site-index.py /var/www/htdocs/dpcpbp.org
"""

import sys
import re
from pathlib import Path
from datetime import datetime

HTDOCS_BASE = Path("/var/www/htdocs")


def extract_title(html: str, fallback: str) -> str:
    m = re.search(r'<title>(.*?)\s*\[encrypted\]</title>', html, re.I)
    if m:
        return m.group(1).strip()
    m = re.search(r'<title>(.*?)</title>', html, re.I)
    return m.group(1).strip() if m else fallback


def generate(htdocs_dir: Path) -> None:
    html_dir = htdocs_dir / "html"
    if not html_dir.is_dir():
        print(f"ERROR: html/ dir not found: {html_dir}", file=sys.stderr)
        sys.exit(1)

    files = sorted(
        f for f in html_dir.iterdir()
        if f.is_file() and f.suffix.lower() in (".html", ".htm")
    )

    items = []
    for f in files:
        title = extract_title(f.read_text(errors="replace"), f.stem)
        items.append((f.name, title))

    domain    = htdocs_dir.name
    generated = datetime.utcnow().strftime("%Y-%m-%d %H:%M UTC")
    links     = "\n".join(
        f'<li><a href="html/{name}">{title}</a></li>'
        for name, title in items
    )

    index_html = f"""<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>{domain}</title>
  <style>
    body {{ font-family: sans-serif; background: #111; color: #ccc;
           max-width: 800px; margin: 2rem auto; padding: 0 1rem; }}
    .header {{ display: flex; justify-content: space-between; align-items: baseline;
               border-bottom: 1px solid #222; padding-bottom: 0.8rem; margin-bottom: 1.2rem; }}
    h1 {{ font-size: 1rem; color: #888; font-weight: normal; margin: 0; }}
    a.files-link {{ font-size: 0.85rem; color: #7aa2c8; text-decoration: none; }}
    a.files-link:hover {{ text-decoration: underline; }}
    ul {{ list-style: none; padding: 0; margin: 0; column-count: 2; column-gap: 2rem; }}
    li {{ padding: 0.15rem 0; font-size: 0.85rem; break-inside: avoid; }}
    li a {{ color: #aaa; text-decoration: none; }}
    li a:hover {{ color: #ddd; }}
    .footer {{ margin-top: 2rem; font-size: 0.75rem; color: #333;
               border-top: 1px solid #1a1a1a; padding-top: 0.8rem; }}
  </style>
</head>
<body>
<div class="header">
  <h1>{domain} &mdash; {len(items)} documents</h1>
  <a class="files-link" href="files/">Files &amp; Downloads &rarr;</a>
</div>
<ul>
{links}
</ul>
<p class="footer">Generated {generated} &middot; All documents encrypted &middot; <a href="files/pubkey.asc" style="color:#333">pubkey.asc</a></p>
</body>
</html>
"""

    out = htdocs_dir / "index.html"
    out.write_text(index_html)
    print(f"  Written: {out}  ({len(items)} documents)")


def main():
    if len(sys.argv) < 2:
        print(__doc__)
        sys.exit(1)

    arg = sys.argv[1]
    htdocs_dir = Path(arg) if "/" in arg else HTDOCS_BASE / arg

    if not htdocs_dir.is_dir():
        print(f"Directory not found: {htdocs_dir}", file=sys.stderr)
        sys.exit(1)

    generate(htdocs_dir)


if __name__ == "__main__":
    main()
