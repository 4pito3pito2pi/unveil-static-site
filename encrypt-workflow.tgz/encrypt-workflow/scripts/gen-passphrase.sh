#!/bin/sh
# gen-passphrase.sh — generate a diceware-style passphrase from system wordlist
#
# Usage:
#   gen-passphrase.sh           Generate 12-word passphrase (~154 bits entropy)
#   gen-passphrase.sh 6         Generate 6-word passphrase  (~77 bits entropy)
#
# Words are filtered to 4-8 chars, lowercase, alpha-only for readability.

WORDS="${1:-12}"
WORDLIST="/usr/share/dict/words"

[ -f "$WORDLIST" ] || { echo "No wordlist at $WORDLIST" >&2; exit 1; }

# Filter: lowercase, alpha only, 4-8 chars
grep -E '^[a-z]{4,8}$' "$WORDLIST" | shuf -n "$WORDS" | tr '\n' ' ' | sed 's/ $/\n/'
