#!/usr/bin/env python3
"""
encrypt-html.py — Encrypt HTML files using AES-256-GCM + PBKDF2-SHA256

Each encrypted file is self-contained: ciphertext, decryption UI, and
(optionally) a GPG signature are all embedded in a single HTML file.

Usage:
  encrypt-html.py <input_dir> <output_dir>   Encrypt all HTML in input_dir
  encrypt-html.py <file.html> <output_dir>   Encrypt a single file
  encrypt-html.py --test                     Round-trip test on a sample file

Passphrase: set ENCRYPT_PASSPHRASE env var, or script will prompt.

Scheme:
  PBKDF2-SHA256, 260000 iterations, 32-byte random salt
  AES-256-GCM, 12-byte random IV
  Output: salt(32) + iv(12) + tag(16) + ciphertext — all base64 in JSON

GPG signing (--sign):
  Signs the ciphertext JSON payload and embeds the armored signature in the
  HTML. No separate .sig file. Verify with: verify-html.sh file.html
"""

import sys
import os
import json
import base64
import getpass
import argparse
import subprocess
from pathlib import Path

from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from html.parser import HTMLParser

ITERATIONS = 260_000
SALT_LEN   = 32
IV_LEN     = 12

# ── Key derivation ─────────────────────────────────────────────────────────────

def derive_key(passphrase: str, salt: bytes) -> bytes:
    kdf = PBKDF2HMAC(
        algorithm=hashes.SHA256(),
        length=32,
        salt=salt,
        iterations=ITERATIONS,
    )
    return kdf.derive(passphrase.encode("utf-8"))

# ── Encrypt / Decrypt ──────────────────────────────────────────────────────────

def encrypt(plaintext: bytes, passphrase: str) -> dict:
    salt = os.urandom(SALT_LEN)
    iv   = os.urandom(IV_LEN)
    key  = derive_key(passphrase, salt)
    ct   = AESGCM(key).encrypt(iv, plaintext, None)  # ct includes 16-byte GCM tag
    return {
        "salt": base64.urlsafe_b64encode(salt).decode(),
        "iv":   base64.urlsafe_b64encode(iv).decode(),
        "ct":   base64.urlsafe_b64encode(ct).decode(),
        "iter": ITERATIONS,
    }

def decrypt(enc: dict, passphrase: str) -> bytes:
    salt = base64.urlsafe_b64decode(enc["salt"])
    iv   = base64.urlsafe_b64decode(enc["iv"])
    ct   = base64.urlsafe_b64decode(enc["ct"])
    key  = derive_key(passphrase, salt)
    return AESGCM(key).decrypt(iv, ct, None)

# ── HTML helpers ───────────────────────────────────────────────────────────────

class TitleExtractor(HTMLParser):
    def __init__(self):
        super().__init__()
        self._in_title = False
        self.title = ""
    def handle_starttag(self, tag, attrs):
        if tag == "title":
            self._in_title = True
    def handle_endtag(self, tag):
        if tag == "title":
            self._in_title = False
    def handle_data(self, data):
        if self._in_title:
            self.title += data

def extract_title(html: str) -> str:
    p = TitleExtractor()
    p.feed(html)
    return p.title.strip() or "Encrypted Document"

def wrap_in_html(enc: dict, title: str, source_filename: str, sig_armor: str = None) -> str:
    enc_json = json.dumps(enc)
    if sig_armor:
        sig_block = (
            '<details class="sig">\n'
            '  <summary>GPG Signature</summary>\n'
            '  <pre class="armor">' + sig_armor.strip() + '</pre>\n'
            '  <p class="hint">verify: <code>verify-html.sh ' + source_filename + '</code></p>\n'
            '</details>'
        )
        sig_style = """
    details.sig { margin-top: 2rem; border-top: 1px solid #222; padding-top: 1rem; text-align: left; }
    details.sig summary { color: #555; cursor: pointer; font-size: 0.8rem; user-select: none; }
    details.sig pre.armor { font-size: 0.65rem; color: #444; white-space: pre-wrap; word-break: break-all; margin: 0.6rem 0 0.4rem; }
    details.sig .hint { font-size: 0.75rem; color: #555; margin: 0; }
    details.sig .hint code { background: #1a1a1a; padding: 1px 4px; border-radius: 3px; }"""
    else:
        sig_block = ""
        sig_style = ""
    return f"""<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="encryption" content="AES-256-GCM/PBKDF2-SHA256/{enc['iter']}">
  <meta name="source" content="{source_filename}">
  <title>{title} [encrypted]</title>
  <style>
    *, *::before, *::after {{ box-sizing: border-box; }}
    body {{ font-family: sans-serif; background: #111; color: #ccc;
           display: flex; align-items: center; justify-content: center;
           height: 100vh; margin: 0; }}
    .box {{ text-align: center; max-width: 380px; width: 100%; padding: 2rem; }}
    h2 {{ font-size: 1rem; color: #888; font-weight: normal; margin: 0 0 1.5rem; }}
    .title {{ font-size: 1.1rem; color: #ddd; margin-bottom: 0.4rem; }}
    input[type=text] {{
      width: 100%; padding: 0.6rem 0.8rem; font-size: 1rem;
      background: #1e1e1e; border: 1px solid #333; border-radius: 5px;
      color: #eee; outline: none; margin-bottom: 0.8rem;
    }}
    input[type=text]:focus {{ border-color: #555; }}
    button {{
      width: 100%; padding: 0.6rem; font-size: 1rem; cursor: pointer;
      background: #2a2a2a; border: 1px solid #444; border-radius: 5px;
      color: #ccc; transition: background 0.15s;
    }}
    button:hover {{ background: #333; }}
    button:disabled {{ opacity: 0.5; cursor: default; }}
    .err {{ color: #e06c75; font-size: 0.85rem; margin-top: 0.8rem; min-height: 1.2em; }}
    .spin {{ display: none; margin-top: 0.8rem; color: #666; font-size: 0.85rem; }}{sig_style}
  </style>
</head>
<body>
<div class="box">
  <div class="title">{title}</div>
  <h2>This document is encrypted</h2>
  <input type="text" id="pw" placeholder="Passphrase" autofocus autocomplete="off" spellcheck="false">
  <button id="btn" onclick="unlock()">Unlock</button>
  <div class="spin" id="spin">Decrypting&hellip;</div>
  <div class="err" id="err"></div>
{sig_block}
</div>
<pre id="enc-data" style="display:none" aria-hidden="true">{enc_json}</pre>
<script>
document.getElementById('pw').addEventListener('keydown', e => {{
  if (e.key === 'Enter') unlock();
}});
async function unlock() {{
  const pw   = document.getElementById('pw').value;
  const btn  = document.getElementById('btn');
  const err  = document.getElementById('err');
  const spin = document.getElementById('spin');
  if (!pw) {{ err.textContent = 'Enter a passphrase.'; return; }}
  btn.disabled = true;
  err.textContent = '';
  spin.style.display = 'block';
  const enc = JSON.parse(document.getElementById('enc-data').textContent);
  const b64 = s => {{
    s = s.trim().replace(/\\s+/g, '').replace(/-/g, '+').replace(/_/g, '/');
    return Uint8Array.from(atob(s), c => c.charCodeAt(0));
  }};
  try {{
    const te  = new TextEncoder();
    const raw = await crypto.subtle.importKey('raw', te.encode(pw), 'PBKDF2', false, ['deriveKey']);
    const key = await crypto.subtle.deriveKey(
      {{ name: 'PBKDF2', salt: b64(enc.salt), iterations: parseInt(enc.iter) || 260000, hash: 'SHA-256' }},
      raw, {{ name: 'AES-GCM', length: 256 }}, false, ['decrypt']
    );
    const plain = await crypto.subtle.decrypt({{ name: 'AES-GCM', iv: b64(enc.iv) }}, key, b64(enc.ct));
    const blob = new Blob([new TextDecoder().decode(plain)], {{type: 'text/html'}});
    location.href = URL.createObjectURL(blob);
  }} catch (_) {{
    spin.style.display = 'none';
    btn.disabled = false;
    err.textContent = 'Wrong passphrase or corrupted data.';
    document.getElementById('pw').select();
  }}
}}
</script>
</body>
</html>
"""

# ── MIME types for binary file encryption ──────────────────────────────────────

MIME_TYPES = {
    ".pdf":  "application/pdf",
    ".wav":  "audio/wav",
    ".mp3":  "audio/mpeg",
    ".flac": "audio/flac",
    ".ogg":  "audio/ogg",
    ".mp4":  "video/mp4",
    ".png":  "image/png",
    ".jpg":  "image/jpeg",
    ".jpeg": "image/jpeg",
    ".gif":  "image/gif",
    ".svg":  "image/svg+xml",
    ".txt":  "text/plain",
    ".md":   "text/plain",
    ".tex":  "text/plain",
    ".py":   "text/plain",
    ".json": "application/json",
    ".csv":  "text/csv",
    ".zip":  "application/zip",
}

HTML_EXTENSIONS = {".html", ".htm"}


def wrap_in_html_binary(enc: dict, original_name: str, mimetype: str, sig_armor: str = None) -> str:
    """Encrypted wrapper for non-HTML files — decrypts and offers file download."""
    enc_json = json.dumps(enc)
    sig_block = ""
    sig_style = ""
    if sig_armor:
        sig_block = (
            '<details class="sig">\n'
            '  <summary>GPG Signature</summary>\n'
            '  <pre class="armor">' + sig_armor.strip() + '</pre>\n'
            '  <p class="hint">verify: <code>verify-html.sh ' + original_name + '.html</code></p>\n'
            '</details>'
        )
        sig_style = """
    details.sig { margin-top: 2rem; border-top: 1px solid #222; padding-top: 1rem; text-align: left; }
    details.sig summary { color: #555; cursor: pointer; font-size: 0.8rem; user-select: none; }
    details.sig pre.armor { font-size: 0.65rem; color: #444; white-space: pre-wrap; word-break: break-all; margin: 0.6rem 0 0.4rem; }
    details.sig .hint { font-size: 0.75rem; color: #555; margin: 0; }
    details.sig .hint code { background: #1a1a1a; padding: 1px 4px; border-radius: 3px; }"""
    ext   = Path(original_name).suffix.lower().lstrip(".")
    return f"""<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="encryption" content="AES-256-GCM/PBKDF2-SHA256/{enc['iter']}">
  <meta name="original-file" content="{original_name}">
  <meta name="mime-type" content="{mimetype}">
  <title>{original_name} [encrypted]</title>
  <style>
    *, *::before, *::after {{ box-sizing: border-box; }}
    body {{ font-family: sans-serif; background: #111; color: #ccc;
           display: flex; align-items: center; justify-content: center;
           min-height: 100vh; margin: 0; }}
    .box {{ text-align: center; max-width: 380px; width: 100%; padding: 2rem; }}
    h2 {{ font-size: 1rem; color: #888; font-weight: normal; margin: 0 0 1.5rem; }}
    .filename {{ font-size: 1.1rem; color: #ddd; margin-bottom: 0.2rem; font-family: monospace; }}
    .filetype {{ font-size: 0.8rem; color: #555; margin-bottom: 1.2rem; }}
    input[type=text] {{
      width: 100%; padding: 0.6rem 0.8rem; font-size: 1rem;
      background: #1e1e1e; border: 1px solid #333; border-radius: 5px;
      color: #eee; outline: none; margin-bottom: 0.8rem;
    }}
    input[type=text]:focus {{ border-color: #555; }}
    button {{
      width: 100%; padding: 0.6rem; font-size: 1rem; cursor: pointer;
      background: #2a2a2a; border: 1px solid #444; border-radius: 5px;
      color: #ccc; transition: background 0.15s;
    }}
    button:hover {{ background: #333; }}
    button:disabled {{ opacity: 0.5; cursor: default; }}
    .err {{ color: #e06c75; font-size: 0.85rem; margin-top: 0.8rem; min-height: 1.2em; }}
    .spin {{ display: none; margin-top: 0.8rem; color: #666; font-size: 0.85rem; }}{sig_style}
  </style>
</head>
<body>
<div class="box">
  <div class="filename">{original_name}</div>
  <div class="filetype">{ext} &middot; encrypted</div>
  <h2>Enter passphrase to download</h2>
  <input type="text" id="pw" placeholder="Passphrase" autofocus autocomplete="off" spellcheck="false">
  <button id="btn" onclick="unlock()">Decrypt &amp; Download</button>
  <div class="spin" id="spin">Decrypting&hellip;</div>
  <div class="err" id="err"></div>
{sig_block}
</div>
<pre id="enc-data" style="display:none" aria-hidden="true">{enc_json}</pre>
<script>
document.getElementById('pw').addEventListener('keydown', e => {{
  if (e.key === 'Enter') unlock();
}});
async function unlock() {{
  const pw   = document.getElementById('pw').value;
  const btn  = document.getElementById('btn');
  const err  = document.getElementById('err');
  const spin = document.getElementById('spin');
  if (!pw) {{ err.textContent = 'Enter a passphrase.'; return; }}
  btn.disabled = true;
  err.textContent = '';
  spin.style.display = 'block';
  const enc = JSON.parse(document.getElementById('enc-data').textContent);
  const b64 = s => {{
    s = s.trim().replace(/\\s+/g, '').replace(/-/g, '+').replace(/_/g, '/');
    return Uint8Array.from(atob(s), c => c.charCodeAt(0));
  }};
  try {{
    const te  = new TextEncoder();
    const raw = await crypto.subtle.importKey('raw', te.encode(pw), 'PBKDF2', false, ['deriveKey']);
    const key = await crypto.subtle.deriveKey(
      {{ name: 'PBKDF2', salt: b64(enc.salt), iterations: parseInt(enc.iter) || 260000, hash: 'SHA-256' }},
      raw, {{ name: 'AES-GCM', length: 256 }}, false, ['decrypt']
    );
    const plain = await crypto.subtle.decrypt({{ name: 'AES-GCM', iv: b64(enc.iv) }}, key, b64(enc.ct));
    const blob = new Blob([plain], {{type: '{mimetype}'}});
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = '{original_name}';
    a.click();
    spin.style.display = 'none';
    btn.textContent = 'Downloaded';
  }} catch (_) {{
    spin.style.display = 'none';
    btn.disabled = false;
    err.textContent = 'Wrong passphrase or corrupted data.';
    document.getElementById('pw').select();
  }}
}}
</script>
</body>
</html>
"""

# ── Download-only wrapper (no embedded JS — for /files/ directory) ──────────────

def wrap_in_html_download(enc: dict, title: str, source_filename: str, sig_armor: str = None) -> str:
    """Minimal encrypted wrapper with no decryption UI — for offline download."""
    enc_json = json.dumps(enc)
    sig_block = ""
    if sig_armor:
        sig_block = (
            '<h3>GPG Signature</h3>\n'
            '<pre class="armor">' + sig_armor.strip() + '</pre>\n'
            '<p>Verify: <code>gpg --verify ' + source_filename + '.sig ' + source_filename + '</code></p>\n'
        )
    return f"""<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="encryption" content="AES-256-GCM/PBKDF2-SHA256/{enc['iter']}">
  <meta name="source" content="{source_filename}">
  <title>{title} [encrypted]</title>
  <style>
    body {{ font-family: monospace; background: #111; color: #888; max-width: 700px; margin: 3rem auto; padding: 0 1rem; }}
    h1 {{ color: #ccc; font-size: 1.1rem; }}
    h3 {{ color: #666; font-size: 0.85rem; margin-top: 2rem; }}
    pre {{ font-size: 0.7rem; color: #555; white-space: pre-wrap; word-break: break-all; }}
    pre.armor {{ border-left: 2px solid #222; padding-left: 0.8rem; }}
    code {{ background: #1a1a1a; padding: 1px 4px; border-radius: 3px; }}
    .meta {{ color: #444; font-size: 0.8rem; margin-bottom: 2rem; }}
  </style>
</head>
<body>
<h1>{title}</h1>
<p class="meta">AES-256-GCM / PBKDF2-SHA256 / {enc['iter']} iterations<br>
Download this file and decrypt offline with <code>decrypt.js</code> or <code>decrypt.py</code>.</p>
{sig_block}
<pre id="enc-data" aria-label="encrypted payload">{enc_json}</pre>
</body>
</html>
"""

# ── Main logic ─────────────────────────────────────────────────────────────────

UTILS_BASE  = Path("/var/www/utils")
HTDOCS_BASE = Path("/var/www/htdocs")
DOC_BASE    = Path("/home/claude/Documents")

def gpg_sign_data(data: bytes) -> str | None:
    """Sign bytes via GPG stdin, return armored signature string or None on failure."""
    result = subprocess.run(
        ["gpg", "--batch", "--yes", "--detach-sign", "--armor"],
        input=data, capture_output=True
    )
    if result.returncode != 0:
        print(f"  GPG sign failed: {result.stderr.decode().strip()}", file=sys.stderr)
        return None
    return result.stdout.decode()


def encrypt_file(src: Path, dest_dir: Path, passphrase: str, sign: bool = False, embed: bool = True):
    """Encrypt one file.
    HTML files: embed=True → full JS UI; embed=False → download-only wrapper + .sig file.
    Non-HTML files: always produce a .html wrapper with decrypt+download JS.
    Output filename: same name for HTML; original_name + '.html' for binary files.
    """
    is_html = src.suffix.lower() in HTML_EXTENSIONS
    data    = src.read_bytes()
    enc     = encrypt(data, passphrase)
    enc_json = json.dumps(enc)
    sig_armor = gpg_sign_data(enc_json.encode()) if sign else None
    if sign:
        print("  signed" if sig_armor else "  sign failed")

    if is_html:
        title = extract_title(data.decode("utf-8", errors="replace"))
        if embed:
            wrapped = wrap_in_html(enc, title, src.name, sig_armor)
        else:
            wrapped = wrap_in_html_download(enc, title, src.name, sig_armor)
            if sig_armor:
                (dest_dir / (src.name + ".sig")).write_text(sig_armor)
        dest = dest_dir / src.name
    else:
        mimetype = MIME_TYPES.get(src.suffix.lower(), "application/octet-stream")
        wrapped  = wrap_in_html_binary(enc, src.name, mimetype, sig_armor)
        if sig_armor:
            (dest_dir / (src.name + ".html.sig")).write_text(sig_armor)
        dest = dest_dir / (src.name + ".html")

    dest.write_text(wrapped)
    print(f"  encrypted: {dest.name}")
    return dest


def needs_update(src: Path, dest: Path) -> bool:
    """True if src is newer than dest or dest doesn't exist."""
    return not dest.exists() or src.stat().st_mtime > dest.stat().st_mtime


def encrypt_domain(domain: str):
    """
    Domain mode — mirrors ~/Documents/ to the web, encrypted + signed.

      Source HTML:  ~/Documents/html/        → htdocs/html/  (embedded JS)
                                             → htdocs/files/ (download, no JS)
      Source other: ~/Documents/{pdf,docx,   → htdocs/files/ (download wrapper)
                    txt,downloads,...}/

      Passphrase:   /var/www/utils/<domain>/passphrase.txt
      Incremental:  only re-encrypts files newer than their output.
    """
    utils_dir  = UTILS_BASE  / domain
    htdocs_dir = HTDOCS_BASE / domain
    html_dir   = htdocs_dir / "html"
    files_dir  = htdocs_dir / "files"
    doc_dir    = DOC_BASE

    pp_file = utils_dir / "passphrase.txt"
    if not pp_file.exists() or not pp_file.stat().st_size:
        print(f"Passphrase not found or empty: {pp_file}", file=sys.stderr)
        sys.exit(1)
    passphrase = pp_file.read_text().strip()

    html_dir.mkdir(parents=True, exist_ok=True)
    files_dir.mkdir(parents=True, exist_ok=True)

    # ── HTML files from ~/Documents/html/ ─────────────────────────────────────
    html_src_dir = doc_dir / "html"
    html_sources = sorted(
        f for f in html_src_dir.rglob("*")
        if f.is_file() and f.suffix.lower() in HTML_EXTENSIONS
    ) if html_src_dir.is_dir() else []

    # ── Binary files from all other subdirs (recursive) ───────────────────────
    binary_sources = sorted(
        f for f in doc_dir.rglob("*")
        if f.is_file()
        and f.suffix.lower() not in HTML_EXTENSIONS
        and not any(part == "html" for part in f.relative_to(doc_dir).parts[:-1])
    )

    total   = len(html_sources) + len(binary_sources)
    updated = 0

    print(f"Domain:  {domain}")
    print(f"Source:  {doc_dir}")
    print(f"  HTML:  {len(html_sources)} files  →  {html_dir}")
    print(f"  Other: {len(binary_sources)} files  →  {files_dir}")
    print()

    for src in html_sources:
        dest_html  = html_dir  / src.name
        dest_files = files_dir / src.name
        if needs_update(src, dest_html) or needs_update(src, dest_files):
            print(f"  [html] {src.name}")
            encrypt_file(src, html_dir,  passphrase, sign=True, embed=True)
            encrypt_file(src, files_dir, passphrase, sign=True, embed=False)
            updated += 1
        else:
            print(f"  [skip] {src.name}")

    for src in binary_sources:
        dest_files = files_dir / (src.name + ".html")
        if needs_update(src, dest_files):
            print(f"  [bin]  {src.name}")
            encrypt_file(src, files_dir, passphrase, sign=True, embed=False)
            updated += 1
        else:
            print(f"  [skip] {src.name}")

    print(f"\n{updated}/{total} files updated.")

def run_test():
    print("=== Round-trip test ===")
    sample = Path("/tmp/enc-test-sample.html")
    sample.write_text("""<!DOCTYPE html>
<html><head><title>Test Document</title></head>
<body><h1>Hello World</h1><p>Secret content: 42 is the answer.</p></body>
</html>""")

    passphrase = "correct-horse-battery-staple"
    print(f"Passphrase: {passphrase}")

    out_dir = Path("/tmp/enc-test-out")
    out_dir.mkdir(exist_ok=True)
    dest = encrypt_file(sample, out_dir, passphrase)

    # Verify round-trip — extract JSON from pre tag
    import re as _re
    enc_html = dest.read_text()
    m = _re.search(r'<pre id="enc-data"[^>]*>(\{.*?\})</pre>', enc_html, _re.S)
    assert m, "enc-data pre tag not found"
    enc = json.loads(m.group(1))

    recovered = decrypt(enc, passphrase).decode("utf-8")
    assert "Secret content: 42" in recovered, "Decryption mismatch!"
    assert "Hello World" in recovered

    print(f"Encrypted file: {dest}")
    print(f"Decryption: OK — content verified")
    print(f"Encrypted size: {dest.stat().st_size} bytes")
    print(f"Original size:  {sample.stat().st_size} bytes")
    print("=== Test passed ===")

def main():
    parser = argparse.ArgumentParser(description=__doc__,
        formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("input",  nargs="?", help="Domain name, input file, or input directory")
    parser.add_argument("output", nargs="?", help="Output directory (not used in domain mode)")
    parser.add_argument("--test", action="store_true", help="Run round-trip test")
    parser.add_argument("--sign", action="store_true", help="GPG-sign each encrypted file")
    args = parser.parse_args()

    if args.test:
        run_test()
        return

    if not args.input:
        parser.print_help()
        sys.exit(1)

    # Domain shortcut: single arg with a dot and no path separators
    if args.output is None and "." in args.input and "/" not in args.input:
        encrypt_domain(args.input)
        return

    if not args.output:
        parser.print_help()
        sys.exit(1)

    passphrase = os.environ.get("ENCRYPT_PASSPHRASE", "").strip()
    if not passphrase:
        passphrase = getpass.getpass("Passphrase: ")
        confirm    = getpass.getpass("Confirm:    ")
        if passphrase != confirm:
            print("Passphrases do not match.", file=sys.stderr)
            sys.exit(1)

    src = Path(args.input)
    dest_dir = Path(args.output)
    dest_dir.mkdir(parents=True, exist_ok=True)

    if src.is_file():
        encrypt_file(src, dest_dir, passphrase, sign=args.sign)
    elif src.is_dir():
        files = [f for f in src.iterdir()
                 if f.is_file() and f.suffix.lower() in (".html", ".htm")]
        print(f"Encrypting {len(files)} files from {src} → {dest_dir}")
        for f in sorted(files):
            encrypt_file(f, dest_dir, passphrase, sign=args.sign)
        print(f"Done.")
    else:
        print(f"Input not found: {src}", file=sys.stderr)
        sys.exit(1)

if __name__ == "__main__":
    main()
