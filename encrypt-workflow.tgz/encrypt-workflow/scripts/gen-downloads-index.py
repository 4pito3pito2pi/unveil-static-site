#!/usr/bin/env python3
"""
gen-downloads-index.py — generate index.html for the downloads directory

Scans ~/Documents/downloads/ and produces a clean HTML page listing all files
with download links, file size, and type icon.

Usage:
  gen-downloads-index.py       Regenerate ~/Documents/downloads/index.html
"""

import os
from pathlib import Path
from datetime import datetime

DOWNLOADS_DIR = Path.home() / "Documents" / "downloads"

ICONS = {
    ".pdf":  "📄",
    ".docx": "📝",
    ".doc":  "📝",
    ".txt":  "📃",
    ".zip":  "🗜",
    ".tgz":  "🗜",
    ".gz":   "🗜",
    ".py":   "🐍",
    ".sh":   "⚙",
    ".ksh":  "⚙",
    ".js":   "⚙",
    ".html": "🌐",
    ".htm":  "🌐",
    ".json": "📋",
    ".csv":  "📊",
    ".png":  "🖼",
    ".jpg":  "🖼",
    ".svg":  "🖼",
}

def fmt_size(n):
    if n >= 1_048_576: return f"{n/1_048_576:.1f} MB"
    if n >= 1_024:     return f"{n/1_024:.1f} KB"
    return f"{n} B"

def build_index():
    files = sorted(
        [f for f in DOWNLOADS_DIR.iterdir() if f.is_file() and f.name != "index.html"],
        key=lambda f: f.name.lower()
    )

    rows = []
    for f in files:
        ext  = f.suffix.lower()
        icon = ICONS.get(ext, "📁")
        size = fmt_size(f.stat().st_size)
        mtime = datetime.fromtimestamp(f.stat().st_mtime).strftime("%Y-%m-%d")
        name = f.name
        rows.append(
            f'    <tr>\n'
            f'      <td>{icon}</td>\n'
            f'      <td><a href="{name}" download>{name}</a></td>\n'
            f'      <td>{ext[1:].upper() if ext else "—"}</td>\n'
            f'      <td>{size}</td>\n'
            f'      <td>{mtime}</td>\n'
            f'    </tr>'
        )

    html = f"""<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Downloads</title>
  <style>
    body {{ font-family: sans-serif; max-width: 860px; margin: 2em auto; padding: 0 1em; }}
    h1 {{ font-size: 1.2em; color: #444; border-bottom: 1px solid #ddd; padding-bottom: 0.4em; }}
    table {{ width: 100%; border-collapse: collapse; }}
    th {{ text-align: left; padding: 6px 10px; border-bottom: 2px solid #ddd;
          font-size: 0.85em; color: #666; }}
    td {{ padding: 5px 10px; border-bottom: 1px solid #f0f0f0; font-size: 0.9em; }}
    td:first-child {{ width: 1.5em; text-align: center; }}
    td:nth-child(3), td:nth-child(4), td:nth-child(5) {{ color: #888; width: 6em; }}
    a {{ text-decoration: none; color: #1a0dab; }}
    a:hover {{ text-decoration: underline; }}
    .count {{ color: #aaa; font-weight: normal; font-size: 0.85em; }}
  </style>
</head>
<body>
  <h1>Downloads <span class="count">({len(files)} files)</span></h1>
  <table>
    <thead>
      <tr>
        <th></th>
        <th>File</th>
        <th>Type</th>
        <th>Size</th>
        <th>Date</th>
      </tr>
    </thead>
    <tbody>
{chr(10).join(rows) if rows else '      <tr><td colspan="5" style="color:#aaa;padding:1em">No files yet.</td></tr>'}
    </tbody>
  </table>
</body>
</html>
"""
    out = DOWNLOADS_DIR / "index.html"
    out.write_text(html)
    print(f"Written: {out} ({len(files)} files)")

if __name__ == "__main__":
    build_index()
