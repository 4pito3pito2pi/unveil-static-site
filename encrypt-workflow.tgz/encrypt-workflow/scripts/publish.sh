#!/bin/sh
# publish.sh — encrypt and publish ~/Documents/ to dpcpbp.org
#
# Mirrors ~/Documents/ to the web, encrypted and signed.
# Only re-encrypts files newer than their published output (incremental).
#
# Usage: sh /home/claude/publish.sh

set -e
DOMAIN="dpcpbp.org"
SCRIPTS="/home/claude"

python3 "$SCRIPTS/encrypt-html.py"    "$DOMAIN"
python3 "$SCRIPTS/gen-site-index.py"  "$DOMAIN"
python3 "$SCRIPTS/gen-files-index.py" "$DOMAIN"
