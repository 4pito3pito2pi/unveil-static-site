#!/bin/sh
# setup.sh — one-time setup for dpcpbp.org publishing workflow
#
# - Imports GPG key from encrypt-workflow/keys/
# - Generates 12-word passphrase into passphrase.txt (if not already set)
# - Runs initial publish (encrypts everything in utils/html/)
#
# Safe to re-run (idempotent — skips steps already done).
#
# Usage: sh /home/claude/setup.sh

set -e

DOMAIN="dpcpbp.org"
UTILS="/var/www/utils/$DOMAIN"
HTDOCS="/var/www/htdocs/$DOMAIN"
SCRIPTS="/home/claude"
KEY_ID="736897086FA4FB21E8C20DBC82C16B5C25D5FB00"

echo "=== dpcpbp.org publish setup ==="
echo

# ── Directories ───────────────────────────────────────────────────────────────
echo "--- Directories ---"
mkdir -p "$UTILS" "$HTDOCS/html" "$HTDOCS/files"
echo "  $UTILS         (passphrase + utils)"
echo "  $HTDOCS/html   (encrypted site)"
echo "  $HTDOCS/files  (downloads)"
echo "  Source: ~/Documents/ (add files there, then run publish.sh)"
echo

# ── GPG key ───────────────────────────────────────────────────────────────────
echo "--- GPG key ---"
if gpg --list-secret-keys "$KEY_ID" > /dev/null 2>&1; then
    echo "  Already imported: $KEY_ID"
else
    # Look in the extracted workflow bundle first, then fall back
    for keyfile in \
        "$UTILS/encrypt-workflow/keys/gpg-private.asc" \
        "$SCRIPTS/keys/gpg-private.asc" \
        "$HOME/gpg-private.asc"
    do
        if [ -f "$keyfile" ]; then
            gpg --batch --import "$keyfile"
            echo "  Imported from: $keyfile"
            break
        fi
    done
    if ! gpg --list-secret-keys "$KEY_ID" > /dev/null 2>&1; then
        echo "  ERROR: key not found — cannot sign files" >&2
        exit 1
    fi
fi

# Export public key to files/
gpg --armor --export "$KEY_ID" > "$HTDOCS/files/pubkey.asc"
echo "  Public key → $HTDOCS/files/pubkey.asc"
echo

# ── Passphrase ────────────────────────────────────────────────────────────────
echo "--- Passphrase ---"
PP="$UTILS/passphrase.txt"
if [ -f "$PP" ] && [ -s "$PP" ]; then
    echo "  Already exists: $PP"
else
    sh "$SCRIPTS/gen-passphrase.sh" > "$PP"
    echo
    echo "  ╔══════════════════════════════════════════════════════╗"
    echo "  ║  WRITE THIS DOWN — LOSS = PERMANENT DATA LOSS       ║"
    echo "  ╚══════════════════════════════════════════════════════╝"
    echo "  $(cat "$PP")"
fi
echo

# ── Initial publish ───────────────────────────────────────────────────────────
echo "--- Initial publish ---"
sh "$SCRIPTS/publish.sh"
